

| \[Company Name]\[Your Company Slogan] | INVOICE |
| --- | --- |
| \[Street Address]\[City, ST ZIP Code]Phone: \[Phone] Fax: \[Fax] | Invoice \#\[100]Date: \[Date] |
| To:\[Recipient Name]\[Company Name]\[Street Address]\[City, ST ZIP Code]Phone: \[Phone] | Ship To:\[Recipient Name]\[Company Name\[Street Address]\[City, ST ZIP Code]Phone: \[Phone] |

| Comments or special instructions:\[To get started right away, just tap any placeholder text (such as this) and start typing to replace it with your own.] |
| --- |
| | SALESPERSON | P.O. NUMBER | REQUISITIONER | SHIPPED VIA | F.O.B. POINT | TERMS | | --- | --- | --- | --- | --- | --- | |  |  |  |  |  | \[Due on receipt] | |

| QUANTITY | DESCRIPTION | UNIT PRICE | TOTAL |
| --- | --- | --- | --- |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |

|  | SUBTOTAL |  |
| --- | --- | --- |
|  | SALES TAX |  |
|  | SHIPPING \& HANDLING |  |
|  | TOTAL due |  |

Make all checks payable to \[Company Name]

If you have any questions concerning this invoice, contact \[Name, phone, email]

Thank you for your business!


